<template>
  <div class="info">
    <h1>동물의숲 정보 페이지</h1>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
