<template>
  <div class="community">
    <h1>동물의숲 커뮤니티 페이지</h1>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
